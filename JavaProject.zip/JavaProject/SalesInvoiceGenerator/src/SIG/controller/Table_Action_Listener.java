/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SIG.controller;


import java.util.ArrayList;
import Model_Sales_Invoice.Inv_Header;
import Model_Sales_Invoice.Inv_Line;
import Model_Sales_Invoice.Inv_Line_Table;
import Design_Sales_Invoice.Sales_Inv_Frame;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;



public class Table_Action_Listener implements ListSelectionListener{
   private Sales_Inv_Frame frame;

    public Table_Action_Listener(Sales_Inv_Frame frame) {
        this.frame = frame;
    }
   

    @Override
    public void valueChanged(ListSelectionEvent e) {
        int indexOfSelectedRow=frame.getjTable_Invoice().getSelectedRow();
        System.out.println("Invoice you selected is : " + indexOfSelectedRow);

        if (indexOfSelectedRow != -1) {
            
        Inv_Header selectedRow =frame.getInvoicesArr().get(indexOfSelectedRow);
        ArrayList<Inv_Line> lines=selectedRow.getLines();
        Inv_Line_Table lineTable=new Inv_Line_Table(lines);
        frame.setLinesArr(lines);
         frame.getjTable_Items().setModel(lineTable);
          frame.getjTextField_CustomerName().setText(selectedRow.getCustomerName());
           frame.getjLabel_InvoiceNumber().setText(selectedRow.getNumber()+"");
            frame.getjLabel_InvoiceTotal().setText(selectedRow.getTotalInvoice()+"");
             frame.getjTextField_InvoiceDate().setText(Sales_Inv_Frame.date.format(selectedRow.getDate()));
        
        }
       
    }

    private void getLines() {
     
    }
    
}
