/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model_Sales_Invoice;


public class Inv_Line {
    private Inv_Header header ;
    private double price;
    private int count;
    private String itemName;
   

    public Inv_Line() {
    }

    public Inv_Line(Inv_Header header, String itemName, double price, int count) {
        this.header = header;
       
        this.itemName = itemName;
        
        this.price = price;
        
        this.count = count;
    }

    public Inv_Header getHeader() {
        return header;
    }

    
    public void setHeader(Inv_Header header) {
        this.header = header;
    }

    public String getItemName() {
        return itemName;
    }

    
    
    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public double getPrice() {
        return price;
    }

    
    
    public void setPrice(double price) {
        this.price = price;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
    
    public double getTotalLine(){
        return count * price;
    }

    @Override
    public String toString() {
       
        return  header.getNumber() + "," + itemName + "," + price + "," + count ;
    }

    
}
